package Q2;
import Lab6Q.*;
import java.io.*;
import java.util.*;

public class DemoFileAbeer {
    public static void main(String[] args) throws IOException {
        //assigns and declares variables
        int count = 0;
        double real;
        double im;
        Scanner input = new Scanner (System.in);
        MyMethod.printHeader(7,2); //prints header
        int size = 3;
        RecComplexNum [] recArr = new RecComplexNum[size]; //creates recComplexNum class

        //loop which collects the imaginary and real part of each value in array
        while (count<size){
            System.out.printf("Please enter the real part for recArr[%d]: ", count); //gets real
            real = input.nextDouble();
            System.out.printf("Please enter the imaginary part for recArr[%d]: ", count); //gets imaginary
            im = input.nextDouble();
            recArr[count] = new RecComplexNum(real,im); //assigns value to each location
            count++;
        }
        System.out.println("\nArray of Rectangular Complex numbers is:"); //title
        count = 0;
        while (count<size){ //outputs the array on screen loop
            System.out.printf("recArr[%d] = ",count); //displays each array
            recArr[count].displayRecForm();
            System.out.println();
            count++;
        }

        //POLAR EQUIVALENT NUMBERS
        PolarComplexNum [] polarArr = new PolarComplexNum[3]; //creates polarComplexNum type variable
        polarArr = returnPolarForm(recArr); //passes recArr through return polar and assigns polar array
        count = 0;
        System.out.println("\nCorresponding Array of Polar Complex numbers is:");
        while (count<size){ //assigns each point in the array with the corresponding polar value from rec array
            System.out.printf("PolarArr[%d] = ",count);
            polarArr[count].displayPolarForm();
            System.out.println();
            count++;
        }

        // CREATES FILE AND PUTS INFO IN FILE
        count = 0;
        PrintWriter writeToFile = new PrintWriter("DataFileAbeer.txt"); //creates file
        String sign;
        int multiplier;
        while (count<size){
            if (recArr[count].getImaginary()< 0){ //if im less than zero siplays negative in output equation
                sign = "-";
                multiplier=-1; //gets rid of negative from number
            }
            else{
                sign = "+"; //else it is plus sign nad remains the same
                multiplier = 1;
            }
            // writes the value to file in required format until reaches end of array
            writeToFile.printf("%.2f %s %.2f = Magnitude: %.2f, Angle: %.2f\n",recArr[count].getReal(),sign,recArr[count].getImaginary()*multiplier, polarArr[count].getMagnitude(),polarArr[count].getAngle());
            count++;
        }
        writeToFile.close(); // closes file

    }
    public static PolarComplexNum [] returnPolarForm(RecComplexNum[] arr){ //return polar form method
        int size = 3;
        PolarComplexNum [] array = new PolarComplexNum[size];
        int count = 0;
        while (count<size){ // loop which adds each rec numbers equivalent to the polar array
            array[count] = arr[count].getPolarFromRec();
            count++;
        }
        return array; //returns array
    }
}
