package Q1;

public class Number {
    private double arr[]; //assigns a variable
    public Number(double arr[]){
        this.arr = arr; //takes the inputted variable and assigns to this private one
    }
    public double getMax(){ //get max  from array
        int length = arr.length; // takes length of array
        double max = 0;
       for (int i = 0;i<length; i++){ // starts count at 0 until reaches the last number in array
            if (arr[i] > max){ // if the point in the array is greater than the max it assigns a new max val
                max = arr[i];
            }
        }
        return max; //returns max value

    }
    public double getMin(){ //get min of array
        int length = arr.length; //gets length again
        double min = arr[0]; //originally assigns the min value as the first array value and compares from there
        for (int i = 1;i<length; i++){  // atarts comparing each array value with the value assigned to the min
            if (arr[i]<min){
                min = arr[i]; // assigns new min if condition is satisfied
            }
        }
        return min; // returns min


    }
    public double getAverage(){ //gets avg
        int count = 0; //
        double  total = 0;
        while (count<arr.length){
            total += arr[count]; //adds each value of array until end of array is reached
            count++;
        }
        return (total/arr.length); //returns the avg
    }
    public void printArr(){ //prints array
        int count =0;
        System.out.println("Printing Array:");
        while (count<arr.length){
            System.out.printf("arr[%d] = %.2f\n",count, arr[count]); //prints each value of array until end of array reached
            count++;
        }
    }
}
