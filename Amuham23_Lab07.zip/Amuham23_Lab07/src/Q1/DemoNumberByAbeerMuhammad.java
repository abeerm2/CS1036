package Q1;
import Lab6Q.*;

import java.util.*;
public class DemoNumberByAbeerMuhammad {
    public static void main(String[] args) {
        int size;
        Scanner input = new Scanner (System.in);
        MyMethod.printHeader(7,1); //calls header
        System.out.print("Enter the size of the array: "); //asks for array size
        size = input.nextInt(); //assigns input to size variable
        input.nextLine(); //clears buffer
        double [] array = new double [size]; //assigns a variable size to the array
        populateArray(array); //sneds to method
        Number polarArr = new Number(array); //creaters number type variable
        System.out.println();
        polarArr.printArr(); //calls print method
        System.out.printf("\nMaximum value in array = %.2f",polarArr.getMax()); //outputs max
        System.out.printf("\nMinimum value in array = %.2f",polarArr.getMin()); //output min
        System.out.printf("\nAverage of the values in array = %.2f",polarArr.getAverage()); //output avg
        MyMethod.printFooter("Goodbye From Abeer Muhammad"); //calls footer
    }
    public static void populateArray(double[]ar){
        int count = 0;
        Scanner input = new Scanner (System.in);
        while (count<ar.length){ //loop used to ask for each value of the array until size of array reached
            System.out.printf("Please enter the value for arr[%d]: ", count);
            ar[count] = input.nextDouble();
            count++;
        }


    }

}
