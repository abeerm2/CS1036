package Lab6Q;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 14, 2021*
 * My method class, created sin and cosine functions which can be called for required output*
 *********************************************/
public class MyMethod {
    public static double myPow (double x,double y){ //my own power method which can get power of any digit
        double n = y;
        double result = 1;
        while (n>0){
            result = result*x;
            n--;
        }
        return result;
    }
    public static double mySin(double x){ //sine function, which calculates the sine of a digit
        int N = 20;
        double y = 0;
        for (int n = 0; n<= N; n++){
            double p1 = 1;
            for (int i = 1; i<=2*n+1;i++){
                p1 = myPow(x,i);
            }
            double p2 = 1;
            for (int j = 1;j<=2*n+1;j++){
                p2*=j;
            }
            double p3= 1 ;
            for (int k = 1; k<=n;k++){
                p3 = myPow(-1,k);
            }
            y = y + ((p3/p2)*p1);
        }
        return y;
    }
    public static double myCos(double x){ //calculates the cosine of a number when called
        int N = 20;
        double y = 0;
        for (int n = 0; n<= N; n++){
            double p4 = 1;
            for (int i = 1; i<=2*n;i++){
                p4 = myPow(x,i);
            }
            double p5 = 1;
            for (int j = 1;j<=2*n;j++){
                p5*=j;
            }
            double p6= 1 ;
            for (int k = 1; k<=n;k++){
                p6 = myPow(-1,k);
            }
            y = y + ((p6/p5)*p4);
        }
        return y;

    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints ending footer
        System.out.println("\n*** "+message+" ***"); //prints footer message

    }
}
