package Lab6Q;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 14, 2021*
 * Converts polar number to rectangular form, displays polar*
 *********************************************/
public class PolarComplexNum {
    //defines variables
    private double magnitude;
    private double angle;

    public PolarComplexNum(){
        magnitude = 0;
        angle = 0;
    }
    public PolarComplexNum (double mag,double ang){ //class that assigns user inputed variables to private variables
        magnitude = mag;
        angle = ang;
    }
    public RecComplexNum GetRecFromPolar(){ //gets polar from rectangular and calls on recComplex number class
        double real= magnitude*MyMethod.myCos(Math.toRadians(angle)); //gets the real of the polar
        double imaginary = magnitude*MyMethod.mySin(Math.toRadians(angle)); //gets the imaginary of polar
        RecComplexNum output = new RecComplexNum(real,imaginary); //senfs to rec complex num
        return output; //returns to driver
    }
    public void displayPolarForm(){
        System.out.printf("Magnitude: %.2f, Angle: %.2f deg.",magnitude,angle); //displays
    }
    public double getMagnitude(){
        return magnitude;
    }
    public double getAngle(){
        return angle;
    }
}
