import Q1.Circle;

import java.util.Scanner;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 1, 2021*
 *  Driver class which will call the Circle class and print required output *
 *********************************************/
public class CircleInfoAbeer {
    public static void main(String[] args) {
        int labNum = 4;
        int quesNum = 1; // question number
        double userRadius; // user defined radius
        printHeader(labNum,quesNum); //header method

        //creating new scanner for input
        Scanner input = new Scanner (System.in);
        //gets radius
        System.out.print("Please enter a radius: ");
        userRadius = input.nextDouble(); //assigns input to variable

        Circle answer = new Circle(userRadius); //calls and creates new variable for circle class

        System.out.println("The circle's area is "+answer.getArea()); //prints area and gets from circle class
        System.out.println("The circle's diameter is "+answer.getDiameter()); //gets diameter from circle class and prints
        System.out.println("The circle's circumference is "+answer.getCircumference()); //gers circumference from circle class


        printFooter (); //calls footer method


    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (){ //prints ending footer
        System.out.println("\n\n*** Goodbye from Abeer Muhammad ***"); //prints footer message

    }
}
