package Q2;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 1, 2021*
 *  Driver class which is used to output the info assigned using the Student class  *
 *********************************************/
public class StudentDemoClassAbeer {
    public static void main(String[] args) {
        //declaring and assigning required variables
        int labNum = 4;
        int quesNum = 2; // question number
        String exitMessage = "Goodbye from Abeer Muhammad"; //goodbye message
        printHeader(labNum,quesNum); //header method
        System.out.printf ("\nHere is my information:\n======================="); //prints my info

        Student person = new Student(); // creates new student class variable and prints all my info
        System.out.printf("\nI am %s\nStudent Number: %d\nEmail Address: %s\nAge: %d",person.getName(),person.getStudentNumber(),person.getEmailAddress(),person.getAge());

        //creates new variable for next person and also assigns all required values
        Student person1 = new Student(250221375,"Addie","Sloqgrave");
        person1.setYearOfBirth(1999);
        person1.setEmail("aslowgrave4@thetimes.co.uk");//aslowgrave4@thetimes.co.uk

        // creates new variable for next person and also assigns all required values
        Student person2 = new Student (250309716,"Talia","Hanscom");
        person2.setYearOfBirth(2000);
        person2.setEmail("thanscom1@google.es");//thanscom1@google.es

        //creates new variable for next person and also assigns all required values
        Student person3 = new Student (250136525,"Valeria","McCloughen");
        person3.setYearOfBirth(1998);
        person3.setEmail("vmccloughen2@chronoengine.com");//vmccloughen2@chronoengine.com

        //prints all the info in the correct format, with required formatting using printf
        System.out.printf("\n\nHere is the info on other students:\n=================================================================\nNumber%8s%20s Email Address\n========= ==================== === ==============================","Name","Age");
        System.out.printf("\n%d %8s%9d %s",person1.getStudentNumber(),person1.getName(),person1.getAge(),person1.getEmailAddress()); //addie
        System.out.printf("\n%d %8s%11d %s",person2.getStudentNumber(),person2.getName(),person2.getAge(),person2.getEmailAddress());// talia
        System.out.printf("\n%d %8s%6d %s",person3.getStudentNumber(),person3.getName(),person3.getAge(),person3.getEmailAddress());//valeria

        printFooter (exitMessage); //calls footer method

    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints ending footer
        System.out.println("\n\n*** "+message+" ***"); //prints footer message

    }
}
