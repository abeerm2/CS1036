package Q2;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 1, 2021*
 * Class that takes the variables from the driver class which will return desired output when called   *
 *********************************************/

public class Student {
    //creates all required variables from uml diagram
    private int studentNumber;
    private String firstName;
    private String lastName;
    private String emailAddress;
    private int yearOfBirth;

    public Student(){
        //assigns all information about me, when called these variables will be used in this class and then called in driver to get output
        studentNumber = 251143649;
        firstName = "Abeer";
        lastName = "Muhammad";
        emailAddress = "amuham23@uwo.ca";
        yearOfBirth = 2002;


    }
    //takes information from driver and assigns variables to desired input
    public Student (int sn,String fName, String IName){
        studentNumber = sn;
        firstName = fName;
        lastName = IName;
        emailAddress= ""; //email and YOB is left emptied to be assingned later
        yearOfBirth = 0;
    }
    public void setEmail (String em){ // email must be assigned seperately in driver class (called seperately)
        emailAddress = em;
    }
    public void setYearOfBirth (int yb){
        yearOfBirth = yb;
    } //assigns yob value when driver class calls it


    public String getName(){ // returns string of full name by concatenation
        String name = firstName +" "+lastName; //declares new variable name which combines users first and last
        return name; //returns final name
    }
    public int getStudentNumber (){
        return studentNumber;
    } //returns student number

    public String getEmailAddress(){
        return emailAddress;
    } //returns email to driver class

    public int getAge(){ //calculates and returns actual age of person
        int age = 2021 - yearOfBirth;
        return age;
    }
}
