package Q3;
import java.util.Scanner;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 1, 2021*
 *  Driver class which will call the complexNumber class and print required output *
 *********************************************/
public class ComplexNumberDemoAbeer {
    public static void main(String[] args) {
        //assigning and declaring required variables
        int labNum = 4;
        int quesNum = 3; // question number
        // real num 1 and 2- input by user
        double real1;
        double real2;
        //imaginary num 1 and 2, input by user
        double im1;
        double im2;
        // variables to get correct sign (pos or negative)
        String sign,sign2,signFinal;
        int multiplier;

        String exitMessage = "Goodbye from Abeer Muhammad"; //goodbye message
        printHeader(labNum,quesNum); // calls header method

       //output title
        System.out.printf ("\nAbeer’s complex-number adder:\n=============================\nLet's add two complex numbers:\n");
        //Gets user input
        Scanner input = new Scanner (System.in);
        // first complex number entries
        System.out.print("Enter the real part of the first number: ");//prompt
        real1 = input.nextDouble(); // takes double value entered
        input.nextLine(); //clears buffer
        System.out.print("Enter the imaginary part of the first number: "); //prompt
        im1 = input.nextDouble();
        input.nextLine(); //clears buffer

        //second complex number entries
        System.out.print("Enter the real part of the second number: "); //prompt
        real2 = input.nextDouble();
        input.nextLine();
        System.out.print("Enter the imaginary part of the second number: "); //prompt
        im2 = input.nextDouble();
        input.nextLine();
        System.out.printf("\nYou entered the following complex numbers:\n"); //prompt

        //if statement for the added complex number equation, this will make sure the signs are correct when outputting
        if ((im1+im2) < 0){ // if the two imaginaries are less than 0
            signFinal = "-"; // makes the sign negative in the final added equation
        }
        else{
            signFinal = "+"; //otherwise positive
        }
        //for first equation
        if (im1<0){ // if first entered im1 is less than 0
            sign = "-"; // makes it negative in output equation
        }
        else {
            sign = "+"; //otherwise positive
        }
        // second equation
        if (im2<0){ // if im2 is less than 0
            sign2 = "-"; // makes sign negative in output equation
        }
        else {
            sign2 = "+"; // otherwise positive
        }

        ComplexNumber complex1 = new ComplexNumber (real1,im1); // calls complexnumber class
        ComplexNumber complex2 = new ComplexNumber (real2,im2); //calls complex number class for second equation

        // these if statements will correct the final output
        if (sign =="-"){
            multiplier = -1; //removes negative from physical number when outputting and will format correctly
        }
        else{
            multiplier = 1;
        }
        System.out.printf("A = %.2f %s %.2fi",complex1.getReal(),sign,complex1.getImaginary()*multiplier); // prints first equation

        //same thing as above
        if (sign2 =="-"){
            multiplier = -1;
        }
        else{
            multiplier = 1;
        }
        System.out.printf ("\nB = %.2f %s %.2fi",complex2.getReal(),sign2,complex2.getImaginary()*multiplier); // prints second equation

        //same thing as above
        if (signFinal =="-"){
            multiplier = -1;
        }
        else{
            multiplier = 1;
        }
        //declares complex3
        ComplexNumber complex3 = new ComplexNumber ();
        complex3 = complex3.addTwoComplexNumbers(complex1,complex2); //calls the add numbers class
        System.out.printf ("\nHere is the result\nA+B = %.2f %s %.2fi",complex3.getReal(),signFinal,complex3.getImaginary()*multiplier);

        printFooter (exitMessage); //calls footer method // prints the footer
    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints ending footer
        System.out.println("\n\n*** "+message+" ***"); //prints footer message

    }
}
