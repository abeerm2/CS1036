package Q3;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 1, 2021*
 * Class that takes the variables from the driver class which will return desired output when called   *
 *********************************************/
public class ComplexNumber {
    // creating two private variables
    private double real;
    private double imaginary;

    public ComplexNumber (){ //default constructor which assigns real and imaginary as 0
        real = 0;
        imaginary= 0;
    }
    public ComplexNumber (double re,double im){ // will assign private variables and variables from driver class to eachother
        real = re;
        imaginary = im;

    }
    public double getReal(){ // returns the real value when called
        return real;
    }
    public double getImaginary(){ //returns imaginary when called
        return imaginary;
    }

    public ComplexNumber addTwoComplexNumbers(ComplexNumber a, ComplexNumber b){ //adds the two complex numbers
        ComplexNumber finalans = new ComplexNumber(0,0);
        finalans.real = a.real+b.real; //adds the real numbers of each
        finalans.imaginary = a.imaginary+b.imaginary; //adds the imaginary numbers of both
        return finalans; //returns required info for complex3 to driver class
    }
}
