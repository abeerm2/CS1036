package Q1;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 1, 2021*
 * Class that takes the variables from the driver class which will return desired output when called   *
 *********************************************/
public class Circle {
    private double radius; //radius variable
    private final double PI = 3.14159; //creates private final type variable

    public Circle(){ //default constructor
        System.out.println("This is the default constructor.");

    }
    public Circle (double rad){ // takes variable used to call from driver class and assigns to private variable radius
        radius = rad;

    }
    public void setRadius(double rad){ //sets radius
        radius = rad;

    }
    public double getRadius(){ //gets radius will return if called
        return radius;

    }
    public double getArea(){ //takes the radius and returns it to driver class after calculating its area
        double area = PI*radius*radius;
        return area;
    }
    public double getDiameter(){ //takes the radius and returns it to driver class after calculating its diameter
        double diameter = radius*2;
        return diameter;
    }
    public double getCircumference(){ //takes the radius and returns it to driver class after calculating its circumference
        double circumference = 2*PI*radius;
        return circumference;
    }


}

