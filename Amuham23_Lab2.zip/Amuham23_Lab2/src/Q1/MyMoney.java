package Q1;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * February 1, 2021*
 * Variables declared and assigned, the system then prints the output*
 *********************************************/
public class MyMoney {
    public static void main(String[] args) {
        String preferredFullName = "Abeer Muhammad"; //declaring name of user as a String
        int age = 18; //declaring age, int bc whole number
        double expectedSalary = 120000.32; // declaring salary, double bc salary is to the cent
        System.out.println("My name is "+preferredFullName+", my age is "+age+" and\n\tto earn $"+expectedSalary+" per year."); // prints output

    }
}
