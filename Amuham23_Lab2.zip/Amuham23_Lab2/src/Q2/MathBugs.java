package Q2;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * February 1, 2021*
 * Asking the user to input a number within a range, and calculating the RMS *
 *********************************************/
import java.util.Scanner;
public class MathBugs {
    public static void main(String[] args) {
        int num; //variable declaration of type int
        Scanner input = new Scanner(System.in); //defining name of scanner object
        System.out.print("Please enter a number from 11 to 99 (inclusive): "); //prompts user
        num = input.nextInt(); // reads the integer from input
        int tensDigit = num / 10; //divides number by 10 to get tensdigit, does not take decimal (int)
        int UnitsDigit = num % 10; //takes remainder of the division
        double rootMeanSquared = Math.sqrt(((float)(tensDigit*tensDigit)+(UnitsDigit*UnitsDigit))/2); //formula for RMS
        System.out.printf("The root mean squared of "+ num +" is %.2f",rootMeanSquared); //output statement

    }
}
