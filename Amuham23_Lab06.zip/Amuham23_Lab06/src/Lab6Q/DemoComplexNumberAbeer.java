package Lab6Q;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 14, 2021*
 * Driver class which calls on all required classes and outputs for user, uses a menu, if statements, and user input*
 *********************************************/
import java.util.*;
public class DemoComplexNumberAbeer {
    public static void main(String[] args) {
        MyMethod.printHeader(6,1);//calls print header method from mymethod class
        //declaring variables
        RecComplexNum rec;
        PolarComplexNum polar;
        double angle,im,magnitude,real;
        Scanner input = new Scanner (System.in);
        int choice; //user choice variable

        while (true){
            //prints menu of all the options
            System.out.printf("**** Complex Number Conversion *****\n *************************************\n1)\tRectangular/Cartesian to Polar\n2)" +
                    "\tPolar to Rectangular/Cartesian\n3)\tExit!\n*************************************\n");
            System.out.print("What conversion would you like to perform? ");
            choice = input.nextInt(); // takes double value entered
            input.nextLine(); //clears buffer
            switch (choice){
                case 1: // if rec to polar is chosen
                    System.out.println("Converting Rectangular/Cartesian To Polar: \n"); //prints prompt
                    System.out.print("Enter the real part: ");//prompt
                    real = input.nextDouble(); // takes double value entered
                    input.nextLine(); //clears buffer
                    System.out.print("Enter the imaginary part: "); //prompt
                    im = input.nextDouble(); //takes im valuee
                    input.nextLine(); //clears buffer
                    System.out.println("Result in Polar Form\n-----------------------------"); //prints header for output
                    rec = new RecComplexNum(real,im); // assigns rec variable
                    rec.displayRecForm(); //displays output by calling class
                    polar = rec.getPolarFromRec(); // gets the polar from rec
                    System.out.println();
                    polar.displayPolarForm();
                    System.out.println("\n");
                    break;
                case 2: //if polar to rec is chosen
                    System.out.println("Converting Polar to Rectangular/Cartesian form: \n");
                    System.out.print("Enter the magnitude: ");//prompt
                    magnitude = input.nextDouble(); // takes double value entered
                    input.nextLine(); //clears buffer
                    System.out.print("Enter the angle value in degrees: "); //prompt
                    angle = input.nextDouble(); //gets angle
                    System.out.println("Result in Rectangular Form\n-----------------------------");
                    polar = new PolarComplexNum(magnitude,angle); //sends to polarcomplex num class
                    polar.displayPolarForm(); //outputs the reuqired answer
                    rec = polar.GetRecFromPolar();//turns polar to rec
                    System.out.println();
                    rec.displayRecForm(); //displays in rec form
                    System.out.println("\n");
                    break;
                case 3:
                    break; //breaks it

            }
            if (choice>3 || choice<1){ //if number is not in 1-3 range runs again
                System.out.println("This is an invalid choice. Choose from 1 to 3.");
                System.out.println();
            }
            if (choice == 3){ //if they want to exit
                break;
            }
        }
        MyMethod.printFooter("Goodbye from Abeer Muhammad"); //calls print foorter from mymethod
    }
}
