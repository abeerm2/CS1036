package Lab6Q;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 14, 2021*
 * My Rectangular number class, can turn rec to polar, and display rec*
 *********************************************/
public class RecComplexNum {
    // creating two private variables
    private double real;
    private double imaginary;

    public RecComplexNum(){ //default constructor which assigns real and imaginary as 0
        real = 0;
        imaginary= 0;
    }
    public RecComplexNum(double re, double im){ // will assign private variables and variables from driver class to eachother
        real = re;
        imaginary = im;

    }
    public PolarComplexNum getPolarFromRec(){ // turns rec to polar and sends to polarcomplexnumber class
        MyMethod exp1 = new MyMethod(); //calls method
        double mag = Math.sqrt(exp1.myPow(real,2) + exp1.myPow(imaginary,2)); //gets mag
        double angle = Math.toDegrees(Math.atan(imaginary/real)); //gets angle
        PolarComplexNum finalans = new PolarComplexNum (mag,angle);//sends to polar class
        return finalans; //returns to where called
    }
    public void displayRecForm(){ //displays the rectangular form
        String sign;
        int multiplier;
        if (imaginary<0){ //if im less than zero siplays negative in output equation
            sign = "-";
            multiplier=-1; //gets rid of negative from number
        }
        else{
            sign = "+"; //else it is plus sign nad remains the same
            multiplier = 1;
        }
        System.out.printf("Given Rectangular Form A = %.2f %s %.2fi",real,sign,imaginary*multiplier);
    }

}