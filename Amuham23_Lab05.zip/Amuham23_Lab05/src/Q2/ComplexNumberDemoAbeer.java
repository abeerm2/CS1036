package Q2;
import java.util.Scanner;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 4, 2021*
 * Driver class which asks for two complex numbers and a series of calculations can be done and called from the Complex Number class  *
 *********************************************/
public class ComplexNumberDemoAbeer {
    public static void main(String[] args) {
        int labNum = 5;
        int quesNum = 2; // question number
        // real num 1 and 2- input by user
        double real1;
        double real2;
        //imaginary num 1 and 2, input by user
        double im1;
        double im2;
        // variables to get correct sign (pos or negative)
        String sign,sign2,signFinal;
        int multiplier;

        String exitMessage = "Goodbye from Abeer Muhammad"; //goodbye message
        printHeader(labNum,quesNum); // calls header method

        System.out.printf ("\nAbeer's Complex-Number adder\n======================="); //prints my info
        System.out.printf ("\nCalculator for Complex Numbers:\n"); //prints my info
        ////////////////INTRO////////////////////////////////////
        Scanner input = new Scanner (System.in);
        // first complex number entries
        System.out.print("Enter the real part of the first number: ");//prompt
        real1 = input.nextDouble(); // takes double value entered
        input.nextLine(); //clears buffer
        System.out.print("Enter the imaginary part of the first number: "); //prompt
        im1 = input.nextDouble();
        input.nextLine(); //clears buffer

        //second complex number entries
        System.out.print("Enter the real part of the second number: "); //prompt
        real2 = input.nextDouble();
        input.nextLine();
        System.out.print("Enter the imaginary part of the second number: "); //prompt
        im2 = input.nextDouble();
        input.nextLine();
        System.out.printf("\nYou entered the following complex numbers:\n"); //prompt

        ////////////////USER INPUTTED COMPLEX NUMBERS ////////////////////////////////////
        ComplexNumber complex1 = new ComplexNumber (real1,im1); // calls complexnumber class
        ComplexNumber complex2 = new ComplexNumber (real2,im2); //calls complex number class for second equation

        ////////////////OUTPUT OF USER INPUT ////////////////////////////////////
        if (im1<0){ // if first entered im1 is less than 0
            sign = "-"; // makes it negative in output equation
            multiplier = -1;
        }
        else {
            sign = "+"; //otherwise positive
            multiplier = 1;
        }
        System.out.printf("A = %.2f %s %.2fi",complex1.getReal(),sign,complex1.getImaginary()*multiplier); // prints first equation

        if (im2<0){ // if im2 is less than 0
            sign2 = "-"; // makes sign negative in output equation
            multiplier = -1; //removes negative from physical number when outputting and will format correctly
        }
        else {
            sign2 = "+"; // otherwise positive
            multiplier = 1;
        }

        System.out.printf ("\nB = %.2f %s %.2fi",complex2.getReal(),sign2,complex2.getImaginary()*multiplier); // prints second equation

        ////////////////WHAT TASK WOULD YOU LIKE TO PREFORM ////////////////////////////////////
        System.out.printf("\n\nWhat calculation would you like to perform?\n" +
                "1) Addition (A+B)\n" +
                "2) Subtraction (A-B)\n" +
                "3) Multiplication (A*B)\n" +
                "4) Division (A/B)\n" +
                "5) Rectangular to Polar (A/B)");
        System.out.print("\n\nEnter Choice here: "); //allows for user input
        int choice = input.nextInt(); //takes input
        input.nextLine(); //clears

        ////////////////PREFORMING TASKS SWITCH METHOD ////////////////////////////////////
        ComplexNumber complex3 = new ComplexNumber (); // creates new reference variable called complex3
        switch (choice){ //uses switch-case method to find what complex 3 (output) is equal to
            case 1:
                complex3 = complex3.addTwoComplexNumbers(complex1,complex2); //calls the add numbers class
                if (complex3.getImaginary() <0){ //used to format the output
                    signFinal = "-";
                    multiplier = -1;
                }else{
                    signFinal = "+";
                    multiplier = 1;
                }
                System.out.printf ("\nHere is the result\nA+B = %.2f %s %.2fi",complex3.getReal(),signFinal,complex3.getImaginary()*multiplier); //output
                break;
            case 2:
                complex3 = complex3.subtractTwoComplexNumbers(complex1,complex2); //calls the subtract numbers class
                if (complex3.getImaginary() <0){ //same thing as above just formatting
                    signFinal = "-";
                    multiplier = -1;
                }else{
                    signFinal = "+";
                    multiplier = 1;
                }
                System.out.printf ("\nHere is the result\nA-B = %.2f %s %.2fi",complex3.getReal(),signFinal,complex3.getImaginary()*multiplier); //output
                break;
            case 3:
                complex3 = complex3.multiplyTwoComplexNumbers(complex1,complex2); // calls multiplier
                if (complex3.getImaginary() <0){ //formatting
                    signFinal = "-";
                    multiplier = -1;
                }else{
                    signFinal = "+";
                    multiplier = 1;

                }
                System.out.printf ("\nHere is the result\n(A*B) = %.2f %s %.2fi",complex3.getReal(),signFinal,complex3.getImaginary()*multiplier); //output
                break;
            case 4:
                complex3 = complex3.divideTwoComplexNumbers(complex1,complex2); //calls the divide numbers class
                if (complex3.getImaginary() <0){ //formatting
                    signFinal = "-";
                    multiplier = -1;
                }else{
                    signFinal = "+";
                    multiplier = 1;
                }
                System.out.printf ("\nHere is the result\n(A/B) = %.2f %s %.2fi",complex3.getReal(),signFinal,complex3.getImaginary()*multiplier); // output
                break;
            case 5:
                System.out.print("\n\nWould you like to convert A or B: "); //if you choose converting user needs to specify which equation so it asks this when selected
                String finalChoice = input.nextLine(); // takes the input
                switch (finalChoice){ //uses case switch method to see which equation goes to convert method
                    case "A":
                        rectangularToPolarForm(complex1); //if a takes complex1
                        break;
                    case "B":
                        rectangularToPolarForm(complex2); //if b takes complex2
                        break;
                }
                break;
        }

        printFooter(exitMessage); //calls footer method // prints the footer //prints footer and ends program
    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints ending footer
        System.out.println("\n*** "+message+" ***"); //prints footer message

    }
    public static void rectangularToPolarForm(ComplexNumber a){ //converts rect form to polar
        String sign; //formatting
        int multiplier;
        if (a.getImaginary()<0){
             sign = "-"; // makes it negative in output equation
            multiplier = -1;
        }
        else {
            sign = "+"; //otherwise positive
            multiplier = 1;
        }
        System.out.printf("%.2f %s %.2fi = Magnitude: %.2f and Angle: %.2f",a.getReal(),sign,a.getImaginary()*multiplier, a.getMagnitude(),a.getAngle()); // prints desired output and calls angle and mag

    }
}
