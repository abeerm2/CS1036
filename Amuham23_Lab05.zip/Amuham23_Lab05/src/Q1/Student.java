package Q1;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 4, 2021*
 * Class that takes the students information including grade and returns it to driver with the letter grade associated with percentage  *
 *********************************************/

public class Student {
    //declares the required variables from UML diagram
    private String name;
    private int studentNumber;
    private int score;
    public Student (){ //first person (i set)
        name = "Harry Potter";
        studentNumber = 251143649;
        score = 50;
    }
    public Student (String nm, int sNum, int sc){ //assigns next person when called from driver
        name = nm;
        studentNumber=sNum;
        score = sc;

    }
    public void getInfo(){ //will print out the info formatted

        System.out.printf("%-15s\t%10d\t%3d",name,studentNumber,score);
    }
    public String getName(){ //returns name to driver
        return name;
    }
    public int getScore(){ //returns their precentage to driver
        return score;
    }

    public String getLetterGrade(){ //uses if statemetns to determine where the score is and what that percentage is as a lettergrade
        String grade = ""; //uses empty string to put the letter grade in when assigned, that way it can be returned
        if (score >= 90){
            grade = "A+";
        }
        else if (score >= 80 || score>90){
            grade = "A-";
        }
        else if (score >= 70 || score>80){
            grade = "B+";
        }
        else if (score >= 60 || score>70){
            grade = "B-";
        }
        else if (score >= 50 || score>60){
            grade = "C+";
        }
        else if (score >= 40 || score>50){
            grade = "C-";
        }
        else if (score >= 30 || score>40){
            grade = "D";
        }
        else {
            grade = "F";
        }


        return grade; //returns the string value of the letter grade

    }
}
