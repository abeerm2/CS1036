package Q1;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * March 4, 2021*
 * Driver class which collects student info and gets sent to Student Class and prints desired output, also compares two students *
 *********************************************/
public class StudentGradesByAbeer {
    public static void main(String[] args) {
        //assigning and declaring required variables
        int labNum = 5;
        int quesNum = 1; // question number
        String exitMessage = "Goodbye from Abeer Muhammad"; //goodbye message
        printHeader(labNum,quesNum); // calls header method
        System.out.printf ("\nHere is my information:\n======================="); //prints my info

        ////////////////////////////////////////////////////

        Student firstStudent = new Student (); //creates first reference variable
        System.out.println(); //empty line
        firstStudent.getInfo(); //prints first students information
        System.out.println("\nLetter Grade: "+firstStudent.getLetterGrade()+"\n"); //gets first students Letter grade

        ///////////////////////////////////////////////////

        Student secondStudent = new Student ("Ron Weasly",211542339,87); //programmer coded info about second person
        secondStudent.getInfo(); //prints student 2's info
        System.out.println("\nLetter Grade: "+secondStudent.getLetterGrade()+"\n"); // returns letter grade of second student

        ///////////////////////////////////////////////////

        if (firstStudent.getScore()> secondStudent.getScore()){ //compares the two students if first greater than second
            System.out.println(firstStudent.getName()+" scored higher than "+ secondStudent.getName()+"!"); // says student1 did better
        }
        else if (secondStudent.getScore()> firstStudent.getScore() ){ //if second student better
            System.out.println(secondStudent.getName()+" scored higher than "+ firstStudent.getName()+"!");
        }
        else{ //if they both have the same grade
            System.out.println(secondStudent.getName()+" and "+ firstStudent.getName()+" scored the same!");
        }
        ///////////////////////////////////////////////////

        printFooter (exitMessage); //calls footer method // prints the footer and ends program
    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints ending footer
        System.out.println("\n*** "+message+" ***"); //prints footer message

    }
}
