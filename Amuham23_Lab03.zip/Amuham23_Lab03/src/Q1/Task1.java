package Q1;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * February 11, 2021*
 * using methods borth void and double types, to return and produced a header, footer, and a desired cm to inch conversion*
 *********************************************/
public class Task1 {
    public static void main(String[] args) {
        //declaring and assigning variables
        int labNum = 3;
        int quesNum = 1; // question number
        double measurement = 3.3; // centimeter value assignment
        String exitMessage = "Thank you! Goodbye."; //goodbye message

        printHeader(labNum,quesNum); //header method
        System.out.printf("\n"+measurement+" cm = %.2f inches ",cmToInchConverter(measurement));//prints and calls the cm inch converter
        printFooter (exitMessage); //calls footer method

    }
    public static void printHeader (int labNum,int quesNum){ //header method
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints ending footer
        System.out.println("\n\n*** "+message+" ***"); //prints footer message

    }
    public static double cmToInchConverter(double measure){
        measure = measure/2.54; //cm to inch calculation
        return measure; // returns the inch value

    }
}
