package Q3;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * February 11, 2021*
 * using methods borth void and double types, to return and produced a header, footer, and a desired Celsius to Fahrenheit conversion*
 *********************************************/
import java.util.Scanner; //importing required scanner

public class Task3 {
    public static void main(String[] args) {
        //declaring and assigning variables
        int labNum = 3;
        int quesNum = 3; //question #3
        double celsius; // assigning couble value to celsius variable
        String exitMessage = "Thank you! Goodbye."; // goodbye statement
        printHeader(labNum,quesNum); // calls print header

        Scanner input = new Scanner(System.in); //defining name of scanner object
        System.out.print("Please enter the temperature you would like to convert: "); //prompts user
        celsius = input.nextDouble(); // reads the double celsius value from input
        //prints out the equivalent fahrenheit value and calls method in same line
        System.out.printf("\n"+celsius+(char) 176 +"C = %.2f"+(char)176 + "F",celsiusToFahrenheit(celsius));

        printFooter (exitMessage);//prints exit message

    }
    public static void printHeader (int labNum,int quesNum){ //method to print the header when called
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //prints header info
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints footer when called
        System.out.println("\n\n*** "+message+" ***");

    }
    public static double celsiusToFahrenheit(double cels){ //method converts celsius to fahrenheit assigned as double
        double fahren = ((cels*9)/5) +32; //equation for conversion
        return fahren; //returns fahrenheit value

    }
}
