package Q2;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * February 11, 2021*
 * Building 5 overload methods called sumValues to return values, incorporating user input to provide desired output  *
 *********************************************/
import java.util.*; //importing random and scanner
public class Task2 {
    public static void main(String[] args) {
        //declaring and assigning variables
        int labNum = 3; //lab #
        int quesNum = 2; //question 2

        //variables used in user input of character question
        String charChoice; //variable for input of character from user
        char finalChoice; //will convert the string character to a char value

        // variables needed to add preset char values
        char char1 = '!',char2 = '$'; //setting variables required to be added in sumValues #3
        int charValue;

        String exitMessage = "Thank you! Goodbye.";
        String firstName;

        printHeader(labNum,quesNum); //calling the header method

        //sending two real numbers to the sum values then printing
        double totalNum = sumValues(2.5,13.6);// calls sumValues #2
        System.out.printf("\nThe total of the 2 real numbers: %.2f",totalNum); //prints sum values to 2 decimal places q1

        //sending two char values to sumValues to be added and produce a new character
        charValue = sumValues(char1,char2); // calls sumValues #3
        System.out.println("\n\nThe sum of characters "+char1+" and "+char2+" is "+(char)charValue);//printing character associated with the two original chars


        //scanner input section asking user for name then sending to sumValues
        Scanner input = new Scanner(System.in); //defining name of scanner object
        System.out.print("\nPlease enter your name: "); //prompts user
        firstName = input.nextLine(); // reads the integer from input
        System.out.printf(sumValues("I am",firstName)); //calling method and printing "I am..." statement

        //next input statement asking for character

        System.out.print("\n\nPlease enter a character: "); //prompts user
        charChoice= input.next(); //takes the string input from user
        finalChoice = charChoice.charAt(0); //takes the first letter, aka the char value
        System.out.printf("The new character generated is: "+sumValues(finalChoice)); //calls sumValues #4 and then prints new character

        //asking user for integer then sending to sumValues to be printed
        input.nextLine();
        System.out.print("\n\nPlease enter an integer: "); //prompts user
        int intChoice = input.nextInt(); //takes the integer input from user
        System.out.printf("The total is: "+sumValues(intChoice)); //sends value to sumValues #5 and prints

        //prints goodbye message
        printFooter (exitMessage);

    }
    public static void printHeader (int labNum,int quesNum){ //called in main method, and set here, prints header
        System.out.println("*********************************");
        System.out.println("\tAbeer Muhammad\n\tLab #"+ labNum + ", Question #" + quesNum); //printing info in header
        System.out.println("*********************************");
    }
    public static void printFooter (String message){ //prints the goodbye message
        System.out.println("\n\n*** "+message+" ***");

    }
    public static String sumValues (String message1, String message2 ) { // sumValues #1 - adding two strings together
        String output = message1+" "+ message2;
        return output; //returns the added strings
    }
    public static double sumValues (double num1, double num2){ // sumValues #2 - adding two real numbers
        double num = num1+num2; //making a local variable
        return num; //sends the new number from addition
    }
    public static int sumValues (char letter1, char letter2){ //sumValues #3
        int newNum = (letter1+letter2); //adds the two characters and also a local variable used
        return (char)newNum; //returns the number value of the new character
    }
    public static char sumValues (char k){ //sumValues #4 - gets user inputted character and adds w random character
        char ch1 = 'E';
        char ch2  = 'K';
        char letter = (char) (ch1 + Math.random() * (ch2 - ch1)+1); //creating the range from which letters can be picked
        System.out.println("The random number generated is: "+letter); //prints the random letter generated
        int newletter = k +letter; //adds the two character (random + user entered)
        return (char)newletter; //returns the new character

    }
    public static int sumValues (int integer1){ //sumValues #5
        Random randomNumbers = new Random();
        int integerRan= 5+ +randomNumbers.nextInt(11);
        System.out.println("Your random integer is: "+integerRan);
        integer1 = integer1+integerRan; //adds the random and entered integer
        return integer1; //returns integer to driver


    }



}
