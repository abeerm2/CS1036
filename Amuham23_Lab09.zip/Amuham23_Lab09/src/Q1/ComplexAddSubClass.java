package Q1;

import Lab6Q.RecComplexNum;

public class ComplexAddSubClass extends RecComplexNum {
    private static int counter;
    public ComplexAddSubClass(){ //constructor
        super();
        counter++;
    }
    public ComplexAddSubClass(double real, double imaginary){ //constructor which sets double and imaginary values from input
        super (real,imaginary); //calls to superclass assigning values
        counter++;
    }
    public static int getCounter(){
        return counter;
    } //returnsa moutn of times class is called
    public static ComplexAddSubClass adder(ComplexAddSubClass a, ComplexAddSubClass b){ //adds complex numbers
        ComplexAddSubClass finala = new ComplexAddSubClass (a.getReal()+b.getReal(), b.getImaginary()+a.getImaginary());
        return finala;
    }
    public static ComplexAddSubClass subtractor(ComplexAddSubClass a, ComplexAddSubClass b){ //subtracts numbers
        ComplexAddSubClass finala = new ComplexAddSubClass (a.getReal()-b.getReal(), a.getImaginary()-b.getImaginary());
        return finala;
    }
    public String toString(){
        String sign;
        int multiplier;
        double imaginary = super.getImaginary();
        if (imaginary<0){ //if im less than zero siplays negative in output equation
            sign = "-";
            multiplier=-1; //gets rid of negative from number
        }
        else{
            sign = "+"; //else it is plus sign nad remains the same
            multiplier = 1;
        }
        return String.format("%.2f %s %.2fi", super.getReal(),sign,super.getImaginary()*multiplier); // displays the output


    }
}
