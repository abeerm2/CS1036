package Q1;
import Lab6Q.*;
import java.util.Scanner;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * April 7, 2021*
 * Driver class which calls on all required classes and outputs for user, uses a menu, if statements, and user input*
 *********************************************/
public class ComplexNumCalcByAbeer {
    //Declaring all required variables from uml diagram
    public static Scanner input = new Scanner(System.in);
    public static ComplexAddSubClass[] recArray = new ComplexAddSubClass[2];
    public static ComplexAddSubClass result;
    public static ComplexMultiDivideClass[] polarArray = new ComplexMultiDivideClass[2];
    public static ComplexMultiDivideClass mdResult = new ComplexMultiDivideClass();
    public static PolarComplexNum pcn = new PolarComplexNum();



    public static void main(String[] args) {
        MyMethod.printHeader(9,1); //calls header
        int choice; //creates choice variable
        String [] letter = {"a","b"}; //for display
        while (true){
            //prints menu of all the options
            System.out.printf("\n**** Complex Number Conversion *****\n *************************************\n" +
                    "1)\t Adder\n" +
                    "2)\t Subtractor\n" +
                    "3)\t Multiplier\n" +
                    "4\t Divider\n" +
                    "5)\t Exit!\n" +
                    "*************************************\n");
            System.out.print("What conversion would you like to perform? "); //asks what task to preform
            choice = input.nextInt(); // takes double value entered
            input.nextLine(); //clears buffer

            //GOES THROUGH ALL CHOICES
            switch (choice){
                case 1: // if rec to polar is chosen
                    dataEntry(); //calls dataentry method
                    System.out.println("Here is your Result of (a + b)\n--------------------------"); //prints prompt
                    System.out.print("a = "+ recArray[0]); //prints first equation
                    System.out.println();
                    System.out.print("b = "+ recArray[1]); //prints second equation
                    System.out.print("\na + b = "+ ComplexAddSubClass.adder(recArray[0],recArray[1])); //prints result
                    System.out.println();
                    break;

                case 2: //if subtractor is chosen
                    dataEntry(); //calls dataentry
                    System.out.println("Here is your Result of (a - b)\n--------------------------"); //prints prompt
                    System.out.print("a = "+ recArray[0]); //prints first equation
                    System.out.println();
                    System.out.print("b = " + recArray[1]); //prints second equation
                    System.out.print("\na - b = " + ComplexAddSubClass.subtractor(recArray[0],recArray[1])); //prints result
                    System.out.println();
                    break;
                case 3:
                    dataEntry(); // calls entry method to get numbers
                    int count = 0;
                    while (count<recArray.length) { // while the count variable is less than the length of the array
                        pcn = recArray[count].getPolarFromRec(); // converts a recarray value to polar rec version
                        polarArray[count] = new ComplexMultiDivideClass(pcn.getMagnitude(),pcn.getAngle()); // assigns point in polar array
                        count++;
                    }
                    mdResult = ComplexMultiDivideClass.multiply(polarArray[0],polarArray[1]); // gets the multiplied version
                    RecComplexNum rresult;
                    rresult = new RecComplexNum(mdResult.GetRecFromPolar().getReal(),mdResult.GetRecFromPolar().getImaginary()); //gets the polar version

                    System.out.println("Here is your Result of (a x b)\n" +
                            "-------------------------------------");
                    count = 0;
                    while (count<recArray.length){ // this prints the proper output
                        System.out.printf("%s = ",letter[count]);
                        recArray[count].displayRecForm();
                        System.out.print(" --> In Polar Form: ");
                        polarArray[count].displayPolarForm();
                        count++;
                        System.out.println();
                    }
                    System.out.println("\na x b = (In Polar) "+mdResult); //prints multiplied output in polar
                    System.out.printf("a x b = (In Rectangle) "); //prints multiplied output in rec
                    rresult.displayRecForm();
                    System.out.println();
                    break;

                case 4:
                    //THIS CASE DOES THE SAME THING AS CASE THREE BUT FOR DIVISION SO ALL THE SAME THINGS APPLY
                    dataEntry();
                    count = 0;
                    while (count<recArray.length) {
                        pcn = recArray[count].getPolarFromRec();
                        polarArray[count] = new ComplexMultiDivideClass(pcn.getMagnitude(),pcn.getAngle());
                        count++;
                    }
                    mdResult = ComplexMultiDivideClass.divide(polarArray[0],polarArray[1]);
                    result = new ComplexAddSubClass(mdResult.GetRecFromPolar().getReal(),mdResult.GetRecFromPolar().getImaginary());

                    System.out.println("Here is your Result of (a / b)\n" +
                            "-------------------------------------");
                    count = 0;

                    while (count<recArray.length){
                        System.out.printf("%s = ",letter[count]);
                        recArray[count].displayRecForm();
                        System.out.print(" --> In Polar Form: ");
                        polarArray[count].displayPolarForm();
                        count++;
                        System.out.println();
                    }
                    System.out.println("\na / b = (In Polar) "+mdResult);
                    System.out.println("a / b = (In Rectangle) "+ result);
                    System.out.println();
                    break;

                case 5:
                    // THIS WILL RETURN THE NUMBER OF TIMES EACH OBJECT HAS BEEN INSTANTIATED
                    System.out.println(ComplexAddSubClass.getCounter() +" ComplexAddSubClass Objects have been instantiated in this program"); //prints the amount of objects
                    System.out.println(ComplexMultiDivideClass.getPolarCounter() +" ComplexMultiDivideClass Objects have been instantiated in this program");
                    break; //breaks it

            }
            if ((double)choice>5 || (double)choice<1){ //if number is not in 1-3 range runs again
                System.out.println("This is an invalid choice. Choose from 1 to 3."); //if wrong number is selected

            }
            if (choice == 5){ //if they want to exit
                break;
            }
        }
        MyMethod.printFooter("Goodbye from Abeer Muhammad"); //prints goodbye message

    }
    public static void dataEntry (){
        //THIS METHOD GETS THE REAL AND IMAGINARY VALUES
        int count =1;
        int arcount =0;
        double real;
        double im;
        while (count <=2) { //runs through loop until it gets two equations
            System.out.printf("Enter real value %d: ", count);
            real = input.nextDouble(); //real
            input.nextLine(); //clear
            System.out.printf("Enter imaginary value %d: ", count); //imaginary
            im = input.nextDouble(); //gets im
            recArray[arcount] = new ComplexAddSubClass(real, im); //calls recaray and creates object
            arcount++;
            count++;
        }
    }
}
