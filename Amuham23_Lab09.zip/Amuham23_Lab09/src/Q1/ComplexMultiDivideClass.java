package Q1;

import Lab6Q.PolarComplexNum;

public class ComplexMultiDivideClass extends PolarComplexNum {
    public static int polarCounter;
    public ComplexMultiDivideClass(){ // Constructor
        super(); //calls super class
        polarCounter++; // increments polar counter everytime this constructor/class is called
    }
    public ComplexMultiDivideClass(double magnitude, double angle){ // second constructor with parameters
        super(magnitude, angle); // calls super constructor which initializes mag and angle
        polarCounter++; //increments
    }

    public static int getPolarCounter() {
        return polarCounter;
    } // when called returns amount of time this class was called

    public static ComplexMultiDivideClass multiply(ComplexMultiDivideClass a, ComplexMultiDivideClass b){ //multiplies two complex numebrs togethers returns new md class type answer
        return new ComplexMultiDivideClass((a.getMagnitude()*b.getMagnitude()), (a.getAngle()+b.getAngle())); //provides info for new equation
    }
    public static ComplexMultiDivideClass divide(ComplexMultiDivideClass a, ComplexMultiDivideClass b){ // same thing but divides
        return new ComplexMultiDivideClass((a.getMagnitude()/b.getMagnitude()), (a.getAngle()-b.getAngle()));
    }
    public String toString(){ // returns the output string of inputted numbers
            return String.format("Magnitude: %.2f, Angle: %.2f degrees", getMagnitude(), getAngle());
    }
}

