package Q2;

public class QuizGrade extends GradeActivity{
    private double [] quizGrades; // creates grade array
    public QuizGrade(double[] quizGr){
        quizGrades = new double[quizGr.length]; //assigns length
        int count = 0;
        while (count<quizGr.length) {
            quizGrades[count] = quizGr[count]; //adds each user inputted number from their array to the classes array
            count++;
        }
        double average = 0;
        for (int i = 0; i < quizGrades.length; i++) //adds up all the quiz averages and divides to get right percentage of course grade
            average += quizGrades[i];
        average = (average / quizGrades.length)*2;
        setScore(average); //sets avg
    }
}
