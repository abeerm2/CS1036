package Q2;

public class Name {
    //declares and assigns first name and last name variables
    private String firstName;
    private String lastName;

    public Name(){} //constructor
    public Name (String fN, String lN){ //assigns user inputted variables to the variables of the class
       firstName = fN;
       lastName =lN;


    }
    public String toString (){
        return String.format("\nName: %s %s", firstName,lastName);
    } //prints output
}
