package Q2;

public class CourseGrades implements Analyzable{
    private GradeActivity [] grades; //creates array  of grades
    public CourseGrades (GradeActivity[]grades){
        this.grades = grades;
    } //assigns driver array to this one
    public GradeActivity getExpectedScore(){ //gets the expected course grade by adding up all the final grades form other classes
        int count = 0;
        double total =0;
        while (count<grades.length){
            total += grades[count].getScore();
            count++;
        }
        GradeActivity finalScore = new GradeActivity(total);
        return finalScore; //returns the expected course grade

    }
    public String toString(){
        //THIS PRINTS EVERYTHING REQUIRED
        return String.format("=========================================================================" +
                        "\nLab Score: %20.2f\tout of 20,\t\t%7.2f%%\t\tGrade: %s" +
                        "\nQuiz Score: %19.2f\tout of 20,\t\t%7.2f%%\t\tGrade: %s" +
                        "\nReading Score: %16.2f\t out of 5,\t\t%7.2f%%\t\tGrade: %s" +
                        "\nMidterm Score: %16.2f\tout of 20,\t\t%7.2f%%\t\tGrade: %s" +
                        "\nFinal Score: %18.2f\tout of 35,\t\t%7.2f%%\t\tGrade: %s\n" +
                        "==========================================================================",
                grades[0].getScore(),(grades[0].getScore())*5, grades[0].getGrade(grades[0].getScore()*5),
                grades[1].getScore(),grades[1].getScore()*5,grades[1].getGrade(grades[1].getScore()*5),
                grades[2].getScore(),grades[2].getScore()*20,grades[2].getGrade(grades[2].getScore()*20),
                grades[3].getScore(),grades[3].getScore()*5, grades[3].getGrade(grades[3].getScore()*5),
                grades[4].getScore(),grades[4].getScore()/35*100,grades[4].getGrade(grades[4].getScore()/35*100));
    }
}
