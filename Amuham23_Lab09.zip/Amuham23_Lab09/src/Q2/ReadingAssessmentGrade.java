package Q2;

public class ReadingAssessmentGrade extends GradeActivity {
    private double[] raGrade;
    //THIS DOES THE SAME THING AS THE QUIZ CLASS BUT JUST FOR READING ONLY CHANGE IS THE AVG
    public ReadingAssessmentGrade(double []readGr){
        raGrade = new double[readGr.length];
        int count = 0;
        while (count<readGr.length) {
            readGr[count] = readGr[count];
            count++;
        }
        double average = 0;
        for (int i = 0; i < readGr.length; i++)
            average += readGr[i];
        average = (average/53); //divided out of 53 because it would be out of 265 and the multiplied by 5 to get how much worth in course
        setScore(average);
    }
}
