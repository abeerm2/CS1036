package Q2;
import Lab6Q.MyMethod;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * April 7, 2021*
 * Driver class which calls on all required classes and outputs for user, uses a menu, if statements, and user input*
 *********************************************/
public class DemoCourseGradeAbeer {
    public static void main(String[] args) {
        MyMethod.printHeader(9,2); //prints header with required input
        CourseAndInstructor coursein = new CourseAndInstructor("Programming Fundamentals","Quazi", "Rehman", "TEB361"); // assigns all info for the course
        StudentInfo me = new StudentInfo("Abeer","Muhammad",251143649,coursein); // creates my info
        System.out.println(me); //prints all of it
        // DECLARING AND ASSIGNING ALL VARIABLES FOR QUIZ MIDTERM LAB ETC
        double [] labG = {30,30,30,30,30,30,30,30,30};
        double [] quizG = {10,10,10,9,10,9};
        double [] readG = {29,24,15,19,21,18,24,19,20,23,35};
        double midtermG = 34;

        //INSTANTIATES ALL THE CLASSES REQUIRED TO GET THE FINAL GRADE FOR EACH COMPONENT
        LabGrade labGrF = new LabGrade(labG); //calls lab class
        ReadingAssessmentGrade readGrF  = new ReadingAssessmentGrade(readG); //reading class
        QuizGrade quizGrF= new QuizGrade(quizG); //quiz class
        GradeActivity mid = new GradeActivity(midtermG/37*20); //sends the midterm grade to grade activity directly
        FinalExam finalMark = new FinalExam(50,2,25,10,100); // sends the exam components to the exam class to calculate

        GradeActivity[] gA = new GradeActivity[5]; // declares and assigns a new array of grade activity type
        int count = 0;
        while (count<gA.length){ // instantiates each object in array
            gA [count] = new GradeActivity();
            count++;
        }
        //ASSIGNS ALL THE CLASS TYPE VARIABLES TO A POINT IN THE GRADEACTIVITY TYPE GA ARRAY
        gA[0] = labGrF;
        gA[1] = quizGrF;
        gA[2] = readGrF;
        gA[3] = mid;
        gA[4] = finalMark;

        CourseGrades myCourse = new CourseGrades(gA); //SENDS all the grades to thecoursegrades
        System.out.println(myCourse); //prints all the course grades
        //GETS BOTH THE EXPECTED LETTER AND PERCENTAGE GRADE
        double score = myCourse.getExpectedScore().getScore();
        char grade = myCourse.getExpectedScore().getGrade(score);
        //PRINTS EXPECTED FINAL GRADES
        System.out.printf("Expected Course score:\t\t\t\t\t\t\t%7.2f%%\t\tGrade: %s\n",score,grade);
        MyMethod.printFooter("I did it!! Goodbye From Abeer Muhammad."); //footer



    }



}
