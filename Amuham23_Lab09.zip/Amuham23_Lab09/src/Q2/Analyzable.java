package Q2;

public interface Analyzable {
    static GradeActivity getExpectedScore(){
        GradeActivity var = new GradeActivity();
        return var;
    }
}
