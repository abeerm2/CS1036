package Q1;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * January 23,2021*
 * Using a simple print statement to print out given phrase *
 *********************************************/
public class WelcomeClass {
    public static void main(String[] args) {
        System.out.print("Welcome to ES1036a course!"); //calling print method to print desired phrase
    }

}
