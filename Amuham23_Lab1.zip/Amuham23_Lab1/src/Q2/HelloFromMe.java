package Q2;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * January 23,2021*
 * Embedding arguments into print statements
 *********************************************/
public class HelloFromMe {
    public static void main(String[] args) {
        System.out.println("Hello, World! My name is " + args [0] + " " + args[1]); //takes the argument (full name) assigned in config and prints
    }
}
