package Q3;
/*******************************************
 * Abeer Muhammad*
 * 251143649*
 * January 23,2021*
 * Taking the square root of a four digit number, and concatenating into a print statement.
 *********************************************/
public class HelloFromMe {
    public static void main(String[] args) {
        int myStudentNumber  = 3649; //Declaring and assigning number to variable
        System.out.println("The last four digits of my Student ID are: " + myStudentNumber); //prints number assigned
        System.out.printf("The square root of " + myStudentNumber + " is : %.2f",
                Math.sqrt(myStudentNumber)); //will print the number assigned, and print its sqrt

    }
}
