package Q1;
import Lab6Q.*;
import java.io.*;
import java.util.Scanner;

public class DemoFileQ1Abeer {
    public static void main(String[] args) throws Exception {
        MyMethod.printHeader(8,1); // prints header
        String FileName; //creates variable for file name
        Scanner input = new Scanner (System.in); // insantiates scanner
        System.out.print("Enter the name of the file to read from: "); //input
        FileName = input.nextLine(); //gets input
        File fr = new File (FileName); //creates file

        if (!fr.exists()){ //checks if file exists
            System.out.println("This file does not exist.");
            System.exit(0); //exits if does
        }
        double [][] array1 = new double [3][2]; //creates array
        Scanner inputFromFile = new Scanner (fr); // gets info from data file
        int count = 0;
        int count2 = 0;
        while (inputFromFile.hasNext()){ //reads through data file
            array1[count][count2] = inputFromFile.nextDouble(); // assigns values to array
            array1[count][count2+1] = inputFromFile.nextDouble(); // 2nd space in row
            count++;
        }
        inputFromFile.close(); //close file
        System.out.println("\nContents of 2D Rectangular Array read from the DataFile.txt:\n");
        print2DArray(array1); // sends to print 2d method
        RecComplexNum [] recArr = new RecComplexNum [3]; //creates recarr
        recArr = squishTo1DRecComplexNumArray(array1); //squishes 2d array to 1d

        PolarComplexNum [] polarArr = new PolarComplexNum[3]; //creates polarComplexNum type variable
        polarArr = returnPolarForm(recArr); //passes recArr through return polar and assigns polar array
        count = 0;

        System.out.println("\nCorresponding Array of Polar Complex numbers is:");
        while (count<3){ //assigns each point in the array with the corresponding polar value from rec array
            System.out.printf("PolarArr[%d] = ",count);
            polarArr[count].displayPolarForm(); //displays polar form version
            System.out.println();
            count++;
        }

        // CREATES FILE AND PUTS INFO IN FILE
        count = 0;
        FileWriter fw = new FileWriter(FileName,true); //creates filewriter variable

        PrintWriter writeToFile = new PrintWriter(fw); //creates file and writes to file
        writeToFile.println("Rectangle to Polar Conversion:"); //title in file
        String sign;
        int multiplier;
        while (count<3){
            if (recArr[count].getImaginary()< 0){ //if im less than zero siplays negative in output equation
                sign = "-";
                multiplier=-1; //gets rid of negative from number
            }
            else{
                sign = "+"; //else it is plus sign nad remains the same
                multiplier = 1;
            }
            // writes the value to file in required format until reaches end of array
            writeToFile.printf("%.2f %s %.2f = Magnitude: %.2f, Angle: %.2f\n",recArr[count].getReal(),sign,recArr[count].getImaginary()*multiplier, polarArr[count].getMagnitude(),polarArr[count].getAngle());
            count++;
        }
        writeToFile.close(); // closes file
        MyMethod.printFooter("Goodbye from Abeer Muhammad");

    }

    public static void print2DArray (double [][] arr){
        int count = 0;
        int count2 = 0;
        while (count<arr.length){ //uses cound to display eachh imaginary and real value
            System.out.printf("%7.2f %7.2fi\n", arr[count][count2], arr[count][count2+1]);
            count++;
        }
    }
    public static RecComplexNum[] squishTo1DRecComplexNumArray(double[][] recArr2D ){ //creates a 1d array from 2d
        RecComplexNum [] arr = new RecComplexNum [3]; //creates rec complex number type array
        int count = 0;
        int count2 = 0;
        double re;
        double im;
        while (count < arr.length){
            re = recArr2D[count][count2]; //gets the real from each row
            im = recArr2D [count][count2+1]; //gets imaginary from each row
            arr[count] = new RecComplexNum(re,im); // puts it in a new variabel type
            count++;
        }
        return arr;
    }
    public static PolarComplexNum [] returnPolarForm(RecComplexNum[] arr){ //return polar form method
        int size = 3;
        PolarComplexNum [] array = new PolarComplexNum[size];
        int count = 0;
        while (count<size){ // loop which adds each rec numbers equivalent to the polar array
            array[count] = arr[count].getPolarFromRec();
            count++;
        }
        return array; //returns array
    }
}
