package Q2;

import Lab6Q.*;
import java.util.Scanner;

public class DemoAddSubClassAbeer {
    //Declaring variables
    private static Scanner input = new Scanner(System.in);
    private static ComplexAddSubClass[] recArray = new ComplexAddSubClass[2];
    private static ComplexAddSubClass result = new ComplexAddSubClass();

    public static void main(String[] args) {
        MyMethod.printHeader(8,2); //calls header
        int choice; //creates choice variable
        while (true){
            //prints menu of all the options
            System.out.printf("\n**** Complex Number Conversion *****\n *************************************\n" +
                    "1)\t Adder\n" +
                    "2)\t Subtractor\n" +
                    "3)\t Exit!\n" +
                    "*************************************\n");
            System.out.print("What conversion would you like to perform? "); //asks what task to preform
            choice = input.nextInt(); // takes double value entered
            input.nextLine(); //clears buffer

            //GOES THROUGH ALL CHOICES
            switch (choice){
                case 1: // if rec to polar is chosen
                    dataEntry(); //calls dataentry method
                    System.out.println("Here is your Result of (a + b)\n--------------------------"); //prints prompt
                    System.out.print("a = "); //prints first equation
                    recArray[0].displayRecForm();
                    System.out.println();
                    System.out.print("b = "); //prints second equation
                    recArray[1].displayRecForm();
                    System.out.print("\na + b = "); //prints result
                    result.adder(recArray[0],recArray[1]);
                    break;

                case 2: //if subtractor is chosen
                    dataEntry(); //calls dataentry
                    System.out.println("Here is your Result of (a - b)\n--------------------------"); //prints prompt
                    System.out.print("a = "); //prints first equation
                    recArray[0].displayRecForm();
                    System.out.println();
                    System.out.print("b = "); //prints second equation
                    recArray[1].displayRecForm();
                    System.out.print("\na - b = "); //prints result
                    result.subtractor(recArray[0],recArray[1]);
                    break;
                case 3:
                    System.out.println(ComplexAddSubClass.getCounter() +" Objects have been instantiated in this program\n"); //prints the amount of objects
                    break; //breaks it

            }
            if (choice>3 || choice<1){ //if number is not in 1-3 range runs again
                System.out.println("This is an invalid choice. Choose from 1 to 3."); //if wrong number is selected
                System.out.println();
            }
            if (choice == 3){ //if they want to exit
                break;
            }
        }
        MyMethod.printFooter("Goodbye from Abeer Muhammad"); //prints goodbye message

    }
    public static void dataEntry (){
        //THIS METHOD GETS THE REAL AND IMAGINARY VALUES
        int count =1;
        int arcount =0;
        double real;
        double im;
        while (count <=2) { //runs through loop until it gets two equations
            System.out.printf("Enter real value %d: ", count);
            real = input.nextDouble(); //real
            input.nextLine(); //clear
            System.out.printf("Enter imaginary value %d: ", count); //imaginary
            im = input.nextDouble(); //gets im
            recArray[arcount] = new ComplexAddSubClass(real, im); //calls recaray and creates object
            arcount++;
            count++;
        }
    }
}
